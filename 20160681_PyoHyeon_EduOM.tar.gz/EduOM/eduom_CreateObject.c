/******************************************************************************/
/*                                                                            */
/*    Copyright (c) 2013-2015, Kyu-Young Whang, KAIST                         */
/*    All rights reserved.                                                    */
/*                                                                            */
/*    Redistribution and use in source and binary forms, with or without      */
/*    modification, are permitted provided that the following conditions      */
/*    are met:                                                                */
/*                                                                            */
/*    1. Redistributions of source code must retain the above copyright       */
/*       notice, this list of conditions and the following disclaimer.        */
/*                                                                            */
/*    2. Redistributions in binary form must reproduce the above copyright    */
/*       notice, this list of conditions and the following disclaimer in      */
/*       the documentation and/or other materials provided with the           */
/*       distribution.                                                        */
/*                                                                            */
/*    3. Neither the name of the copyright holder nor the names of its        */
/*       contributors may be used to endorse or promote products derived      */
/*       from this software without specific prior written permission.        */
/*                                                                            */
/*    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS     */
/*    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       */
/*    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       */
/*    FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE          */
/*    COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,    */
/*    INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    */
/*    BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        */
/*    LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        */
/*    CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      */
/*    LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       */
/*    ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         */
/*    POSSIBILITY OF SUCH DAMAGE.                                             */
/*                                                                            */
/******************************************************************************/
/******************************************************************************/
/*                                                                            */
/*    ODYSSEUS/EduCOSMOS Educational Purpose Object Storage System            */
/*    (Version 1.0)                                                           */
/*                                                                            */
/*    Developed by Professor Kyu-Young Whang et al.                           */
/*                                                                            */
/*    Advanced Information Technology Research Center (AITrc)                 */
/*    Korea Advanced Institute of Science and Technology (KAIST)              */
/*                                                                            */
/*    e-mail: odysseus.educosmos@gmail.com                                    */
/*                                                                            */
/******************************************************************************/
/*
 * Module : eduom_CreateObject.c
 * 
 * Description :
 *  eduom_CreateObject() creates a new object near the specified object.
 *
 * Exports:
 *  Four eduom_CreateObject(ObjectID*, ObjectID*, ObjectHdr*, Four, char*, ObjectID*)
 */


#include <string.h>
#include "EduOM_common.h"
#include "RDsM.h"		/* for the raw disk manager call */
#include "BfM.h"		/* for the buffer manager call */
#include "EduOM_Internal.h"



/*@================================
 * eduom_CreateObject()
 *================================*/
/*
 * Function: Four eduom_CreateObject(ObjectID*, ObjectID*, ObjectHdr*, Four, char*, ObjectID*)
 * 
 * Description :
 * (Following description is for original ODYSSEUS/COSMOS OM.
 *  For ODYSSEUS/EduCOSMOS EduOM, refer to the EduOM project manual.)
 *
 *  eduom_CreateObject() creates a new object near the specified object; the near
 *  page is the page holding the near object.
 *  If there is no room in the near page and the near object 'nearObj' is not
 *  NULL, a new page is allocated for object creation (In this case, the newly
 *  allocated page is inserted after the near page in the list of pages
 *  consiting in the file).
 *  If there is no room in the near page and the near object 'nearObj' is NULL,
 *  it trys to create a new object in the page in the available space list. If
 *  fail, then the new object will be put into the newly allocated page(In this
 *  case, the newly allocated page is appended at the tail of the list of pages
 *  cosisting in the file).
 *
 * Returns:
 *  error Code
 *    eBADCATALOGOBJECT_OM
 *    eBADOBJECTID_OM
 *    some errors caused by fuction calls
 */
Four eduom_CreateObject(
    ObjectID	*catObjForFile,	/* IN file in which object is to be placed */
    ObjectID 	*nearObj,	/* IN create the new object near this object */
    ObjectHdr	*objHdr,	/* IN from which tag & properties are set */
    Four	length,		/* IN amount of data */
    char	*data,		/* IN the initial data for the object */
    ObjectID	*oid)		/* OUT the object's ObjectID */
{
	/* These local variables are used in the solution code. However, you don��t have to use all these variables in your code, and you may also declare and use additional local variables if needed. */
    Four        e;		/* error number */
    Four	neededSpace;	/* space needed to put new object [+ header] */
    SlottedPage *apage;		/* pointer to the slotted page buffer */
    Four        alignedLen;	/* aligned length of initial data */
    Boolean     needToAllocPage;/* Is there a need to alloc a new page? */
    PageID      pid;            /* PageID in which new object to be inserted */
    PageID      nearPid;
    Four        firstExt;	/* first Extent No of the file */
    Object      *obj;		/* point to the newly created object */
    Two         i;		/* index variable */
    sm_CatOverlayForData *catEntry; /* pointer to data file catalog information */
    SlottedPage *catPage;	/* pointer to buffer containing the catalog */
    FileID      fid;		/* ID of file where the new object is placed */
    Two         eff;		/* extent fill factor of file */
    Boolean     isTmp;
    PhysicalFileID pFid;    

    /*@ parameter checking */
    
    if (catObjForFile == NULL) ERR(eBADCATALOGOBJECT_OM);

    if (objHdr == NULL) ERR(eBADOBJECTID_OM);
    
    /* Error check whether using not supported functionality by EduOM */
    if (ALIGNED_LENGTH(length) > LRGOBJ_THRESHOLD) ERR(eNOTSUPPORTED_EDUOM);

    /* Implemented from here */

    /* Calculate size of free space needed to put new object */
    alignedLen = ALIGNED_LENGTH(length);
    neededSpace = sizeof(ObjectHdr) + alignedLen + sizeof(SlottedPageSlot);

    /* Choose page to put new object */

    /* Get sm_CatOverlayForData */
    if ((e = BfM_GetTrain((TrainID*)catObjForFile, (char**)&catPage, PAGE_BUF)) < 0)
        ERR(e);

    GET_PTR_TO_CATENTRY_FOR_DATA(catObjForFile, catPage, catEntry);

    pid = catPage->header.pid;    

    /*If nearObj != NULL */
    if (nearObj != NULL){
        pid.pageNo = nearObj->pageNo;
        if ((e = BfM_GetTrain(&pid, (char**)&apage, PAGE_BUF)) < 0)
            ERR(e);

        /* If the page has enough space */
        if (SP_FREE(apage) >= neededSpace){
            if ((e = om_RemoveFromAvailSpaceList(catObjForFile, &pid, apage)) < 0)
                ERRB1(e, &pid, PAGE_BUF);        
            needToAllocPage = FALSE;
        }

        /* If the page doesn't have enough space */
        else{
            if ((e = BfM_FreeTrain(&pid, PAGE_BUF)) < 0)
                ERR(e);            
            needToAllocPage = TRUE;
        }        
    }

    /*If nearObj == NULL */
    else{
        /* If there's page in available space list */
        isTmp = TRUE;
        switch( 10*(neededSpace + (PAGESIZE-SP_FIXED) - 1)/(PAGESIZE-SP_FIXED) ){
            case 1 :
                if(catEntry->availSpaceList10 != NULL)
                    pid.pageNo = catEntry->availSpaceList10;
                break;
            case 2 :
                if(catEntry->availSpaceList20 != NULL)
                    pid.pageNo = catEntry->availSpaceList20;
                break;            
            case 3 :
                if(catEntry->availSpaceList30 != NULL)
                    pid.pageNo = catEntry->availSpaceList30;
                break;
            case 4 :
                if(catEntry->availSpaceList40 != NULL)
                    pid.pageNo = catEntry->availSpaceList40;
                break;
            case 5 :
                if(catEntry->availSpaceList50 != NULL)
                    pid.pageNo = catEntry->availSpaceList50;
                break;
            default :
                isTmp = FALSE;
        }

        if (isTmp){
            if ((e = om_RemoveFromAvailSpaceList(catObjForFile, &pid, apage)) < 0)
                ERRB1(e, &pid, PAGE_BUF);
            needToAllocPage = FALSE; 
        }
        
        else{
            pid.pageNo = catEntry->lastPage;
            if ((e = BfM_GetTrain(&pid, (char**)&apage, PAGE_BUF)) < 0)
                ERR(e);

            /* Else if there's enough space in the last age of the file */
            if (SP_FREE(apage) >= neededSpace){
                needToAllocPage = FALSE;
            }

            /* Else */
            else{
                if ((e = BfM_FreeTrain((TrainID*)catEntry->lastPage, PAGE_BUF)) < 0)
                    ERR(e);
                needToAllocPage = TRUE;
                //nearObj = catEntry.lastPage;        
            }
        }     
    }

    if (needToAllocPage){
        /* Allocate new page and choose it */
        fid = catEntry->fid;
        if ((e = RDsM_AllocTrains(fid.volNo, firstExt, &nearPid, catEntry->eff, 1, PAGESIZE2, &pid)) < 0)
            ERR(e);        

        if ((e = BfM_GetNewTrain(&pid, (char**)&apage, PAGE_BUF)) < 0)
            ERR(e);

        /* Initialize page header */            
        apage->header.pid = pid;
        SET_PAGE_TYPE(apage, SLOTTED_PAGE_TYPE);
        apage->header.nSlots = 1;
        apage->header.free = 0;                   
        apage->header.unused = 0;
        apage->header.fid = fid;
        apage->header.unique = 0;        
        apage->header.uniqueLimit = 0;        

        /* Insert the page in the list next to nearObj page */ 
        if ((e = om_FileMapAddPage(catObjForFile, (PageID *)nearObj, &pid)) < 0)
            ERRB1(e, &pid, PAGE_BUF);          
    }
    
    else{
        if (SP_CFREE(apage) < neededSpace){
            if ((e = EduOM_CompactPage(apage, NIL)) < 0)
                ERR(e);
        }        
    }
    
    //printf( apage->header.pid);
    /* Update object header */
    objHdr->length = length;
    
    /* Copy an object to the contiguous free area of chosen page */
    obj = (Object *)&(apage->data[apage->header.free]);
    *(Two *)obj = objHdr->properties;
    *(Two *)(obj + 2) = objHdr->tag;
    *(Four *)(obj + 4) = objHdr->length;        
    for (i = 0; i < length; i++){
        *(char *)(obj + sizeof(ObjectHdr)) = data[i];
    }

    /* Update an empty slot or newly allocated slot */
    for (i = 0; i < apage->header.nSlots; i++){
        if(apage->slot[-i].offset = EMPTYSLOT)
            break;
    }
    apage->slot[-i].offset = apage->header.free;

    if ((e = om_GetUnique(&pid, &(apage->slot[-i].unique))) < 0)
        ERRB1(e, &pid, PAGE_BUF);

    /* Update page header */
    if (i == apage->header.nSlots)
        apage->header.nSlots++;
            
    apage->header.free += (sizeof(ObjectHdr) + alignedLen); 
        
    /* Return the new object ID */
    if ((e = om_PutInAvailSpaceList(catObjForFile, &pid, apage)) < 0)
        ERRB1(e, &pid, PAGE_BUF);

    MAKE_OBJECTID(*oid, pid.volNo, pid.pageNo, i, apage->slot[-i].unique);

    if ((e = BfM_SetDirty(&pid, PAGE_BUF)) < 0)
        ERRB1(e, &pid, PAGE_BUF);

    if ((e = BfM_FreeTrain(&pid, PAGE_BUF)) < 0)
        ERR(e);

    if ((e = BfM_FreeTrain((TrainID*)catObjForFile, PAGE_BUF)) < 0)
        ERR(e);

    /* Implemented to here */

    return(eNOERROR);
    
} /* eduom_CreateObject() */